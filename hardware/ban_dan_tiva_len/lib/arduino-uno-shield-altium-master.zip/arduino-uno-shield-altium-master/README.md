Arduino Shield Template for Altium
============================
These headers are made to work with the Arduino Uno R3, Leonardo and new Arduino boards going forward.
